`include "uvm_macros.svh"
import uvm_pkg::*;

class alu_sequence extends uvm_sequence#(alu_seq_item);
    `uvm_object_utils(alu_sequence)

    function new(string name = "alu_sequence");
        super.new(name);
    endfunction

    task body();
        alu_seq_item item;
        repeat(1000) begin
            item = alu_seq_item::type_id::create("item");
            start_item(item);
            assert(item.randomize());
            finish_item(item);
        end
    endtask
endclass