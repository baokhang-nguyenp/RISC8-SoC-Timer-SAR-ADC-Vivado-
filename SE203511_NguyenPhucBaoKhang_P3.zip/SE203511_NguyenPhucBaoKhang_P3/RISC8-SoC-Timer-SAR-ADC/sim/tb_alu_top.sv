`timescale 1ns/1ps
`include "uvm_macros.svh"
import uvm_pkg::*;

`include "alu_seq_item.sv"
`include "alu_sequence.sv"
`include "alu_monitor.sv"
`include "alu_driver.sv"
`include "alu_agent.sv"
`include "alu_scoreboard.sv"
`include "alu_env.sv"
`include "alu_test.sv"

module tb_alu_top;
    logic clk;
    
    // 1. Generate 100MHz clock
    initial begin
        clk = 0;
        forever #5 clk = ~clk; 
    end

    // 2. Instantiate the UVM Interface
    alu_if vif(clk);

    // 3. Instantiate DUT (Design Under Test)
    // Connect the actual ports from alu.v (left) to the interface signals (right)
    alu dut (
        .a      (vif.op_a),       // Operand A
        .b      (vif.op_b),       // Operand B
        .alu_op (vif.alu_ctrl),   // ALU Operation Select
        .y      (vif.alu_result), // 8-bit Result
        .z      (vif.zero),       // Zero flag
        .c      (vif.carry)       // Carry/Borrow flag
    );

    // 4. Configure UVM and Run the Test
    initial begin
        // Register the interface into the UVM configuration database 
        // so the Driver and Monitor can retrieve it.
        uvm_config_db#(virtual alu_if)::set(null, "*", "vif", vif);
        
        // Start the UVM test case named "alu_test"
        run_test("alu_test");
    end
endmodule