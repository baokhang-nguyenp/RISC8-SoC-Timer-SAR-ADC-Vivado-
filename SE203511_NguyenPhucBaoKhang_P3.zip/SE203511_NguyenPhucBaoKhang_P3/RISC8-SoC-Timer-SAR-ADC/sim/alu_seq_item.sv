`include "uvm_macros.svh"
import uvm_pkg::*;

class alu_seq_item extends uvm_sequence_item;
    rand logic [7:0] op_a;
    rand logic [7:0] op_b;
    rand logic [2:0] alu_ctrl;
    
    logic [7:0] alu_result;
    logic       zero;
    logic       carry;

    `uvm_object_utils_begin(alu_seq_item)
        `uvm_field_int(op_a, UVM_ALL_ON)
        `uvm_field_int(op_b, UVM_ALL_ON)
        `uvm_field_int(alu_ctrl, UVM_ALL_ON)
        `uvm_field_int(alu_result, UVM_ALL_ON)
        `uvm_field_int(zero, UVM_ALL_ON)
        `uvm_field_int(carry, UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name = "alu_seq_item");
        super.new(name);
    endfunction
endclass