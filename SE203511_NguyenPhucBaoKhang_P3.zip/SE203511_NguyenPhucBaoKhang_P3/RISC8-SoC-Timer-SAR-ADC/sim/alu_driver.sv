`include "uvm_macros.svh"
import uvm_pkg::*;

class alu_driver extends uvm_driver#(alu_seq_item);
    `uvm_component_utils(alu_driver)
    
    virtual alu_if vif;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if(!uvm_config_db#(virtual alu_if)::get(this, "", "vif", vif))
            `uvm_fatal("DRV", "Could not get vif")
    endfunction

    task run_phase(uvm_phase phase);
        forever begin
            seq_item_port.get_next_item(req);
            @(posedge vif.clk);
            vif.op_a <= req.op_a;
            vif.op_b <= req.op_b;
            vif.alu_ctrl <= req.alu_ctrl;
            seq_item_port.item_done();
        end
    endtask
endclass