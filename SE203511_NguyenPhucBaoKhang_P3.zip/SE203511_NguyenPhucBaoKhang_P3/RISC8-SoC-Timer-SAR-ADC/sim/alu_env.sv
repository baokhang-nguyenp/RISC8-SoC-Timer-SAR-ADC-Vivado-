`include "uvm_macros.svh"
import uvm_pkg::*;

class alu_env extends uvm_env;
    `uvm_component_utils(alu_env)
    
    alu_agent      agent;
    alu_scoreboard scb;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        agent = alu_agent::type_id::create("agent", this);
        scb = alu_scoreboard::type_id::create("scb", this);
    endfunction

    function void connect_phase(uvm_phase phase);
        agent.monitor.mon_ap.connect(scb.item_collected_export);
    endfunction
endclass