`include "uvm_macros.svh"
import uvm_pkg::*;

class alu_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(alu_scoreboard)
    
    uvm_analysis_imp#(alu_seq_item, alu_scoreboard) item_collected_export;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        item_collected_export = new("item_collected_export", this);
    endfunction

    virtual function void write(alu_seq_item item);
        logic [7:0] exp_result;
        logic exp_zero, exp_carry;
        logic [8:0] sum; 

        // Reference Model (Matches exact logic in alu.v)
        case(item.alu_ctrl)
            3'b000: begin sum = {1'b0, item.op_a} + {1'b0, item.op_b}; exp_result = sum[7:0]; exp_carry = sum[8]; end // ADD
            3'b001: begin sum = {1'b0, item.op_a} - {1'b0, item.op_b}; exp_result = sum[7:0]; exp_carry = sum[8]; end // SUB
            3'b010: begin exp_result = item.op_a & item.op_b; exp_carry = 0; end // AND
            3'b011: begin exp_result = item.op_a | item.op_b; exp_carry = 0; end // OR
            3'b100: begin exp_result = item.op_a ^ item.op_b; exp_carry = 0; end // XOR
            3'b101: begin exp_result = {item.op_a[6:0], 1'b0}; exp_carry = item.op_a[7]; end // SHL (Shift left by 1)
            3'b110: begin exp_result = {1'b0, item.op_a[7:1]}; exp_carry = item.op_a[0]; end // SHR (Shift right by 1)
            3'b111: begin exp_result = item.op_b; exp_carry = 0; end // PASSB
            default:begin exp_result = 8'h00; exp_carry = 0; end
        endcase
        
        // Zero flag expectation
        exp_zero = (exp_result == 8'h00) ? 1'b1 : 1'b0;

        // Comparison
        if(item.alu_result !== exp_result || item.zero !== exp_zero || item.carry !== exp_carry) begin
            `uvm_error("SCB_FAIL", $sformatf("Mismatch: a=%0h b=%0h ctrl=%0h | EXP: res=%0h z=%0b c=%0b | ACT: res=%0h z=%0b c=%0b", 
                item.op_a, item.op_b, item.alu_ctrl, exp_result, exp_zero, exp_carry, item.alu_result, item.zero, item.carry))
        end
    endfunction
endclass