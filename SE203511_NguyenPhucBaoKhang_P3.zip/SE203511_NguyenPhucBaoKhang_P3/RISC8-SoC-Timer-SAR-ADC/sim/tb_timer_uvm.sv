`timescale 1ns/1ps
import uvm_pkg::*;
`include "uvm_macros.svh"

// 1. Interface for timer8.v
interface timer_if(input logic clk);
  logic       rst_n;
  logic       en;
  logic       oneshot;
  logic [7:0] presc;
  logic [7:0] load;
  logic [7:0] cmp;
  logic [7:0] cnt;
  logic       ovf_pulse;
  logic       cmp_pulse;
  logic       pwm_out;
endinterface

// 2. Sequence Item
class timer_seq_item extends uvm_sequence_item;
  rand bit       en;
  rand bit       oneshot;
  rand bit [7:0] presc;
  rand bit [7:0] load;
  rand bit [7:0] cmp;
  bit      [7:0] cnt;
  bit            ovf_pulse;
  bit            cmp_pulse;
  bit            pwm_out;

  constraint c_timer {
    en      == 1'b1;
    oneshot == 1'b0; // Periodic mode so timer runs continuously while en=1
    presc inside {[8'd0 : 8'd2]};
    load  inside {[8'd4 : 8'd15]};
    cmp   inside {[8'd1 : load]};
  }

  `uvm_object_utils_begin(timer_seq_item)
    `uvm_field_int(en, UVM_ALL_ON)
    `uvm_field_int(oneshot, UVM_ALL_ON)
    `uvm_field_int(presc, UVM_ALL_ON)
    `uvm_field_int(load, UVM_ALL_ON)
    `uvm_field_int(cmp, UVM_ALL_ON)
  `uvm_object_utils_end

  function new(string name = "timer_seq_item");
    super.new(name);
  endfunction
endclass

// 3. Sequence
class timer_sequence extends uvm_sequence #(timer_seq_item);
  `uvm_object_utils(timer_sequence)
  function new(string name = "timer_sequence");
    super.new(name);
  endfunction

  virtual task body();
    timer_seq_item req;
    repeat (12) begin
      req = timer_seq_item::type_id::create("req");
      start_item(req);
      assert(req.randomize());
      finish_item(req);
    end
  endtask
endclass

// 4. Sequencer
typedef uvm_sequencer #(timer_seq_item) timer_sequencer;

// 5. Driver
class timer_driver extends uvm_driver #(timer_seq_item);
  `uvm_component_utils(timer_driver)
  virtual timer_if vif;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual timer_if)::get(this, "", "vif", vif))
      `uvm_fatal("DRV", "Could not get timer_if")
  endfunction

  virtual task run_phase(uvm_phase phase);
    vif.rst_n   <= 1'b0;
    vif.en      <= 1'b0;
    vif.oneshot <= 1'b0;
    vif.presc   <= 8'd0;
    vif.load    <= 8'd9;
    vif.cmp     <= 8'd3;
    repeat (5) @(posedge vif.clk);
    vif.rst_n   <= 1'b1;
    @(posedge vif.clk);

    forever begin
      seq_item_port.get_next_item(req);
      // Clear counter cleanly for 1 cycle before loading new period/cmp
      vif.en      <= 1'b0;
      vif.oneshot <= req.oneshot;
      vif.presc   <= req.presc;
      vif.load    <= req.load;
      vif.cmp     <= req.cmp;
      @(posedge vif.clk);

      // Enable timer with stable configuration
      vif.en      <= req.en;
      repeat ((req.presc + 1) * (req.load + 2) + 4) @(posedge vif.clk);
      seq_item_port.item_done();
    end
  endtask
endclass

// 6. Monitor with Functional Covergroup
class timer_monitor extends uvm_monitor;
  `uvm_component_utils(timer_monitor)
  virtual timer_if vif;
  uvm_analysis_port #(timer_seq_item) mon_ap;
  timer_seq_item cov_item;

  covergroup timer_cg;
    option.per_instance = 1;
    cp_en:      coverpoint cov_item.en        { bins active = {1}; }
    cp_presc:   coverpoint cov_item.presc     { bins p_low  = {[0:2]}; }
    cp_ovf:     coverpoint cov_item.ovf_pulse { bins pulsed = {1}; bins idle = {0}; }
    cp_cmp:     coverpoint cov_item.cmp_pulse { bins matched = {1}; bins idle = {0}; }
    cp_pwm:     coverpoint cov_item.pwm_out   { bins high = {1}; bins low = {0}; }
  endgroup

  function new(string name, uvm_component parent);
    super.new(name, parent);
    mon_ap = new("mon_ap", this);
    timer_cg = new();
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual timer_if)::get(this, "", "vif", vif))
      `uvm_fatal("MON", "Could not get timer_if")
  endfunction

  virtual task run_phase(uvm_phase phase);
    forever begin
      // Sample on negedge clk so all synchronous & combinational outputs are settled
      @(negedge vif.clk);
      if (vif.rst_n && vif.en) begin
        timer_seq_item tr = timer_seq_item::type_id::create("tr");
        tr.en        = vif.en;
        tr.oneshot   = vif.oneshot;
        tr.presc     = vif.presc;
        tr.load      = vif.load;
        tr.cmp       = vif.cmp;
        tr.cnt       = vif.cnt;
        tr.ovf_pulse = vif.ovf_pulse;
        tr.cmp_pulse = vif.cmp_pulse;
        tr.pwm_out   = vif.pwm_out;
        cov_item     = tr;
        timer_cg.sample();
        mon_ap.write(tr);
      end
    end
  endtask

  virtual function void report_phase(uvm_phase phase);
    `uvm_info("COVERAGE", $sformatf("Timer8 Functional Coverage: %0.2f%%", timer_cg.get_inst_coverage()), UVM_NONE)
  endfunction
endclass

// 7. Scoreboard
class timer_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(timer_scoreboard)
  uvm_analysis_imp #(timer_seq_item, timer_scoreboard) sb_export;

  function new(string name, uvm_component parent);
    super.new(name, parent);
    sb_export = new("sb_export", this);
  endfunction

  virtual function void write(timer_seq_item tr);
    // Check 1: Counter must never exceed LOAD
    if (tr.cnt > tr.load)
      `uvm_error("TIMER_SB", $sformatf("Counter %0d exceeded LOAD %0d", tr.cnt, tr.load))
    // Check 2: PWM rule: pwm_out == (cnt < cmp) when enabled in periodic mode
    if (tr.pwm_out !== (tr.cnt < tr.cmp))
      `uvm_error("TIMER_SB", $sformatf("PWM mismatch: cnt=%0d cmp=%0d pwm=%0b", tr.cnt, tr.cmp, tr.pwm_out))
  endfunction
endclass

// 8. Agent
class timer_agent extends uvm_agent;
  `uvm_component_utils(timer_agent)
  timer_driver    drv;
  timer_sequencer seqr;
  timer_monitor   mon;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    drv  = timer_driver::type_id::create("drv", this);
    seqr = timer_sequencer::type_id::create("seqr", this);
    mon  = timer_monitor::type_id::create("mon", this);
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    drv.seq_item_port.connect(seqr.seq_item_export);
  endfunction
endclass

// 9. Environment
class timer_env extends uvm_env;
  `uvm_component_utils(timer_env)
  timer_agent      agent;
  timer_scoreboard sb;

  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    agent = timer_agent::type_id::create("agent", this);
    sb    = timer_scoreboard::type_id::create("sb", this);
  endfunction

  virtual function void connect_phase(uvm_phase phase);
    agent.mon.mon_ap.connect(sb.sb_export);
  endfunction
endclass

// 10. Test
class timer_test extends uvm_test;
  `uvm_component_utils(timer_test)
  timer_env env;

  function new(string name = "timer_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env = timer_env::type_id::create("env", this);
  endfunction

  virtual task run_phase(uvm_phase phase);
    timer_sequence seq;
    phase.raise_objection(this);
    seq = timer_sequence::type_id::create("seq");
    seq.start(env.agent.seqr);
    phase.drop_objection(this);
  endtask
endclass

// 11. Top-Level UVM Testbench Module
module tb_timer_uvm;
  logic clk = 0;
  always #5 clk = ~clk;

  timer_if tif(clk);

  timer8 u_dut (
    .clk       (clk),
    .rst_n     (tif.rst_n),
    .en        (tif.en),
    .oneshot   (tif.oneshot),
    .presc     (tif.presc),
    .load      (tif.load),
    .cmp       (tif.cmp),
    .cnt       (tif.cnt),
    .ovf_pulse (tif.ovf_pulse),
    .cmp_pulse (tif.cmp_pulse),
    .pwm_out   (tif.pwm_out)
  );

  initial begin
    uvm_config_db#(virtual timer_if)::set(null, "*", "vif", tif);
    run_test("timer_test");
  end
endmodule