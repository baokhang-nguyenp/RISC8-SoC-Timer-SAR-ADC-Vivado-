`include "uvm_macros.svh"
import uvm_pkg::*;

class alu_monitor extends uvm_monitor;
    `uvm_component_utils(alu_monitor)
    
    virtual alu_if vif;
    uvm_analysis_port#(alu_seq_item) mon_ap;

    // 1. Declare Covergroup for functional coverage measurement
    covergroup alu_cg;
        option.per_instance = 1;
        
        // Measure if all 8 ALU operations have been randomly generated
        cp_op: coverpoint vif.alu_ctrl {
            bins add    = {3'b000};
            bins sub    = {3'b001};
            bins and_op = {3'b010};
            bins or_op  = {3'b011};
            bins xor_op = {3'b100};
            bins shl    = {3'b101};
            bins shr    = {3'b110};
            bins passb  = {3'b111};
        }
        
        // Measure if the Zero flag has hit both 0 and 1 states
        cp_zero: coverpoint vif.zero;
        
        // Measure if the Carry flag has hit both 0 and 1 states
        cp_carry: coverpoint vif.carry;
    endgroup

    function new(string name, uvm_component parent);
        super.new(name, parent);
        mon_ap = new("mon_ap", this);
        alu_cg = new(); // Initialize the covergroup
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if(!uvm_config_db#(virtual alu_if)::get(this, "", "vif", vif))
            `uvm_fatal("MON", "Could not get vif")
    endfunction

    task run_phase(uvm_phase phase);
        alu_seq_item item;
        forever begin
            @(posedge vif.clk);
            #1; // Wait for signals to stabilize after the clock edge
            
            item = alu_seq_item::type_id::create("item");
            item.op_a       = vif.op_a;
            item.op_b       = vif.op_b;
            item.alu_ctrl   = vif.alu_ctrl;
            item.alu_result = vif.alu_result;
            item.zero       = vif.zero;
            item.carry      = vif.carry;
            
            // Sample coverage data at each clock cycle
            alu_cg.sample(); 
            
            mon_ap.write(item);
        end
    endtask

    // 2. Report Phase: Tự động chạy vào cuối mô phỏng để in Coverage
    function void report_phase(uvm_phase phase);
        super.report_phase(phase);
        `uvm_info("COVERAGE", $sformatf("ALU Functional Coverage: %0.2f%%", alu_cg.get_inst_coverage()), UVM_NONE)
    endfunction

endclass