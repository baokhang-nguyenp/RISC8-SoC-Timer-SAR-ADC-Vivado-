`ifndef ALU_IF_SV
`define ALU_IF_SV

interface alu_if(input logic clk);
    logic [7:0] op_a;
    logic [7:0] op_b;
    logic [2:0] alu_ctrl;
    logic [7:0] alu_result;
    logic       zero;
    logic       carry;
endinterface

`endif